# Oasis — Desert Restoration Simulator

A browser-based, first-person 3D restoration and automation game. The player starts beside a natural pond with a small bucket, waters individual patches of sand, grows grass, earns coins, upgrades equipment and places autonomous irrigation machines.

## Features

- Three.js first-person world with procedural desert terrain, central pond, palms, dunes, rocks, lighting, fog and ambient dust.
- WASD movement, mouse look, sprint, jump, water collection and manual pouring.
- Persistent per-patch moisture, fertility, growth and restoration state with visible ground transitions and instanced vegetation.
- Coin and restoration-point progression, equipment tiers, player upgrades and unlockable regions.
- Placeable pumps, sprinklers, irrigation towers, fertilizer dispensers and restoration robots.
- Local autosave in the browser, settings, minimap and touch controls.
- Synthesized sound effects and ambience; no unlicensed audio assets.

## Run locally

```bash
python3 -m http.server 4173
```

Then open `http://localhost:4173`. Three.js is loaded as an ES module from jsDelivr; an internet connection is required for the 3D engine.

## Controls

| Action | Control |
| --- | --- |
| Move | WASD |
| Look | Mouse |
| Sprint | Shift |
| Jump | Space |
| Collect water | Hold E beside the pond |
| Pour water | Hold left mouse button while aiming at the ground |
| Pause / release mouse | Esc |
| Place a purchased machine | Select it in Automation, then click the ground |

## Save data

Progress is saved automatically to the current browser's `localStorage` under `oasis-restoration-save-v1`. It is local to that browser and device. A cloud save backend is not configured in this project.

## Deployment

The project is a static site. Deploy the repository root to Vercel with no build command and no output directory override.
