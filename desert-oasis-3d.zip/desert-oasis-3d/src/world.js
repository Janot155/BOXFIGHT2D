import * as THREE from 'three';

export const WORLD_SIZE = 220;
export const TILE_SIZE = 5.5;
export const GRID_SIZE = 33;
export const POND_RADIUS = 13.5;

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const hash = (x, z) => {
  const n = Math.sin(x * 127.1 + z * 311.7) * 43758.5453123;
  return n - Math.floor(n);
};
export function terrainHeight(x, z) {
  const d = Math.hypot(x, z);
  const fade = clamp((d - 16) / 32, 0, 1);
  const h = (Math.sin(x * 0.075) * Math.cos(z * 0.062) * 1.3 + Math.sin((x + z) * 0.027) * 2.1 + Math.sin(x * 0.018 + z * 0.033) * 2.8) * fade;
  return Math.max(-0.08, h);
}

function standard(color, roughness = 0.95, extra = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness, ...extra });
}

export function createWorld(scene) {
  const groundGeometry = new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE, 110, 110);
  const pos = groundGeometry.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = -pos.getY(i);
    pos.setZ(i, terrainHeight(x, z));
  }
  groundGeometry.computeVertexNormals();
  groundGeometry.rotateX(-Math.PI / 2);
  const ground = new THREE.Mesh(groundGeometry, standard('#c8a16a', 1));
  ground.receiveShadow = true;
  ground.name = 'desert-ground';
  scene.add(ground);

  // Subtle dune ridges give the otherwise open terrain a readable silhouette.
  const duneMaterial = standard('#d0ab75', 1);
  for (let i = 0; i < 30; i++) {
    const x = (hash(i, 11) - .5) * 190;
    const z = (hash(i, 19) - .5) * 190;
    if (Math.hypot(x, z) < 30) continue;
    const dune = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 12), duneMaterial);
    dune.position.set(x, terrainHeight(x, z) - 1.2, z);
    dune.scale.set(8 + hash(i, 4) * 10, 2 + hash(i, 3) * 2.4, 12 + hash(i, 5) * 9);
    dune.rotation.y = hash(i, 9) * Math.PI;
    dune.receiveShadow = true;
    scene.add(dune);
  }

  const shore = new THREE.Mesh(new THREE.CircleGeometry(POND_RADIUS + 2.5, 64), standard('#b58f5c', 1));
  shore.rotation.x = -Math.PI / 2;
  shore.position.y = .04;
  shore.receiveShadow = true;
  scene.add(shore);

  const water = new THREE.Mesh(
    new THREE.CircleGeometry(POND_RADIUS, 80),
    new THREE.MeshPhysicalMaterial({ color: '#48a8b8', roughness: .18, metalness: .02, clearcoat: .9, clearcoatRoughness: .12, transparent: true, opacity: .94 })
  );
  water.rotation.x = -Math.PI / 2;
  water.position.y = .48;
  water.receiveShadow = true;
  water.name = 'pond-water';
  scene.add(water);

  const rippleMaterial = new THREE.MeshBasicMaterial({ color: '#b3e9e8', transparent: true, opacity: .15, side: THREE.DoubleSide });
  const ripples = [];
  for (let i = 0; i < 5; i++) {
    const ring = new THREE.Mesh(new THREE.RingGeometry(.8, .88, 48), rippleMaterial.clone());
    ring.rotation.x = -Math.PI / 2;
    ring.position.set((hash(i, 7) - .5) * 15, .51 + i * .001, (hash(i, 14) - .5) * 15);
    ring.userData.phase = hash(i, 21) * Math.PI * 2;
    ring.userData.base = 2.5 + hash(i, 6) * 3;
    scene.add(ring);
    ripples.push(ring);
  }

  const bankRocks = [];
  const rockGeometry = new THREE.DodecahedronGeometry(1, 0);
  const rockMaterial = standard('#8c795c', 1);
  for (let i = 0; i < 42; i++) {
    const a = hash(i, 2) * Math.PI * 2;
    const r = POND_RADIUS + 1 + hash(i, 3) * 2;
    const x = Math.cos(a) * r;
    const z = Math.sin(a) * r;
    const rock = new THREE.Mesh(rockGeometry, rockMaterial);
    rock.position.set(x, terrainHeight(x, z) + .22, z);
    const s = .22 + hash(i, 5) * .55;
    rock.scale.set(s * 1.25, s, s * .9);
    rock.rotation.set(hash(i, 9), hash(i, 7) * 5, hash(i, 8));
    rock.castShadow = true;
    rock.receiveShadow = true;
    scene.add(rock);
    bankRocks.push(rock);
  }

  const palmPositions = [
    [-20, -18, 1.0], [22, -16, .8], [-25, 20, .9], [21, 23, 1.1], [34, 4, .75], [-37, -4, .8],
    [52, -44, 1.2], [-55, -45, 1.15], [62, 35, 1.1], [-70, 43, 1.3], [5, -72, .9], [18, 74, 1.0]
  ];
  palmPositions.forEach(([x, z, s], i) => createPalm(scene, x, z, s, i));

  // Procedural boundary markers and low ruins add scale and orientation.
  const ruinMat = standard('#a98d64', 1);
  for (let i = 0; i < 12; i++) {
    const a = i / 12 * Math.PI * 2;
    const r = 83;
    const x = Math.cos(a) * r;
    const z = Math.sin(a) * r;
    const pillar = new THREE.Mesh(new THREE.BoxGeometry(1.1, 4 + hash(i, 2) * 3, 1.1), ruinMat);
    pillar.position.set(x, pillar.geometry.parameters.height / 2 + terrainHeight(x, z), z);
    pillar.rotation.y = a + .2;
    pillar.castShadow = true;
    scene.add(pillar);
  }

  const dustCount = 900;
  const dustPositions = new Float32Array(dustCount * 3);
  for (let i = 0; i < dustCount; i++) {
    dustPositions[i * 3] = (hash(i, 77) - .5) * 210;
    dustPositions[i * 3 + 1] = .7 + hash(i, 55) * 16;
    dustPositions[i * 3 + 2] = (hash(i, 33) - .5) * 210;
  }
  const dustGeometry = new THREE.BufferGeometry();
  dustGeometry.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
  const dust = new THREE.Points(dustGeometry, new THREE.PointsMaterial({ color: '#e8d2a5', size: .055, transparent: true, opacity: .34, depthWrite: false }));
  scene.add(dust);

  const cells = [];
  const half = (GRID_SIZE - 1) / 2;
  for (let gz = 0; gz < GRID_SIZE; gz++) {
    for (let gx = 0; gx < GRID_SIZE; gx++) {
      const x = (gx - half) * TILE_SIZE;
      const z = (gz - half) * TILE_SIZE;
      if (Math.hypot(x, z) < POND_RADIUS + 2.5) continue;
      cells.push({
        id: `${gx}:${gz}`, gx, gz, x, z,
        stage: 0, moisture: 0, fertility: 0, growth: 0, reserve: 0,
        rewarded: false, zone: zoneAt(x, z), variation: hash(gx, gz)
      });
    }
  }

  const patchGeometry = new THREE.PlaneGeometry(TILE_SIZE - .06, TILE_SIZE - .06);
  patchGeometry.rotateX(-Math.PI / 2);
  const stageMats = [null,
    standard('#8b714f', 1),
    standard('#836d4b', 1),
    standard('#61924c', .94),
    standard('#3d7541', .9)
  ];
  const patches = stageMats.map((mat, i) => {
    if (i === 0) return null;
    const mesh = new THREE.InstancedMesh(patchGeometry, mat, cells.length);
    mesh.name = `terrain-stage-${i}`;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    mesh.count = 0;
    mesh.receiveShadow = true;
    scene.add(mesh);
    return mesh;
  });

  const bladeGeometry = new THREE.BufferGeometry();
  bladeGeometry.setAttribute('position', new THREE.Float32BufferAttribute([
    0, 0, 0, -.105, .52, 0, .06, .28, .025,
    0, 0, 0, .07, .36, -.02, .11, .55, 0
  ], 3));
  bladeGeometry.computeVertexNormals();
  const bladeMat = new THREE.MeshStandardMaterial({ color: '#72a85e', roughness: 1, side: THREE.DoubleSide, vertexColors: false });
  const grass = new THREE.InstancedMesh(bladeGeometry, bladeMat, cells.length * 10);
  grass.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  grass.count = 0;
  grass.castShadow = false;
  scene.add(grass);

  const flowerGeometry = new THREE.IcosahedronGeometry(.13, 0);
  const flowerMat = new THREE.MeshStandardMaterial({ color: '#f3df9b', roughness: .8 });
  const flowers = new THREE.InstancedMesh(flowerGeometry, flowerMat, cells.length);
  flowers.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  flowers.count = 0;
  scene.add(flowers);

  const terrainVisuals = { cells, patches, grass, flowers, patchGeometry, stageMats, lastVisualUpdate: 0 };
  refreshTerrainVisuals(terrainVisuals);

  const machineLayer = new THREE.Group();
  machineLayer.name = 'machines';
  scene.add(machineLayer);

  const effectsLayer = new THREE.Group();
  scene.add(effectsLayer);

  const viewmodel = createViewmodel();
  const player = new THREE.Group();
  scene.add(player);

  return { ground, water, ripples, dust, terrainVisuals, machineLayer, effectsLayer, viewmodel, player, cells };
}

function zoneAt(x, z) {
  if (Math.hypot(x, z) < 47) return 'starting';
  if (z < -45 && Math.abs(x) < 68) return 'palm';
  if (x > 48 && Math.abs(z) < 72) return 'flower';
  if (x < -50 && Math.abs(z) < 70) return 'valley';
  return 'jungle';
}
export { zoneAt };

function createPalm(scene, x, z, scale = 1, seed = 1) {
  const group = new THREE.Group();
  const trunkMat = standard('#8b6340', 1);
  const leafMats = [standard('#3e7148', 1), standard('#4b8050', 1), standard('#5b8d55', 1)];
  const h = 6.3 * scale;
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.23 * scale, .42 * scale, h, 7), trunkMat);
  trunk.position.y = h / 2;
  trunk.rotation.z = -.09;
  trunk.castShadow = true;
  group.add(trunk);
  const crown = new THREE.Group();
  crown.position.set(-.45 * scale, h - .15 * scale, 0);
  for (let i = 0; i < 8; i++) {
    const a = i / 8 * Math.PI * 2 + seed * .3;
    const leaf = new THREE.Mesh(new THREE.ConeGeometry(.46 * scale, 4.4 * scale, 5, 1, false), leafMats[i % leafMats.length]);
    leaf.position.set(Math.cos(a) * 1.55 * scale, -.5 * scale, Math.sin(a) * 1.55 * scale);
    leaf.rotation.z = Math.PI / 2.25;
    leaf.rotation.y = -a + Math.PI / 2;
    leaf.scale.set(1, 1, .35);
    leaf.castShadow = true;
    crown.add(leaf);
  }
  group.add(crown);
  group.position.set(x, terrainHeight(x, z), z);
  group.rotation.y = seed * .73;
  scene.add(group);
  return group;
}

function createViewmodel() {
  const rig = new THREE.Group();
  const bucket = new THREE.Group();
  const bodyMat = standard('#91a19a', .5, { metalness: .5 });
  const darkMat = standard('#4c5b55', .45, { metalness: .55 });
  const rim = new THREE.Mesh(new THREE.TorusGeometry(.205, .025, 8, 24), darkMat);
  rim.rotation.x = Math.PI / 2;
  rim.position.y = .19;
  bucket.add(rim);
  const body = new THREE.Mesh(new THREE.CylinderGeometry(.155, .19, .36, 20, 1, true), bodyMat);
  body.position.y = 0;
  body.castShadow = true;
  bucket.add(body);
  const bottom = new THREE.Mesh(new THREE.CylinderGeometry(.155, .155, .025, 20), darkMat);
  bottom.position.y = -.18;
  bucket.add(bottom);
  const handle = new THREE.Mesh(new THREE.TorusGeometry(.17, .012, 7, 24, Math.PI), darkMat);
  handle.rotation.z = Math.PI;
  handle.position.y = .08;
  bucket.add(handle);
  const water = new THREE.Mesh(new THREE.CircleGeometry(.15, 24), new THREE.MeshBasicMaterial({ color: '#72c9da', transparent: true, opacity: .88, side: THREE.DoubleSide }));
  water.rotation.x = -Math.PI / 2;
  water.position.y = .11;
  bucket.add(water);
  const spout = new THREE.Mesh(new THREE.CylinderGeometry(.035, .06, .52, 10), darkMat);
  spout.rotation.z = Math.PI / 2;
  spout.position.set(.27, .035, 0);
  spout.visible = false;
  bucket.add(spout);
  const nozzle = new THREE.Mesh(new THREE.CylinderGeometry(.075, .095, .25, 12), bodyMat);
  nozzle.rotation.z = Math.PI / 2;
  nozzle.position.set(.34, .03, 0);
  nozzle.visible = false;
  bucket.add(nozzle);
  const tank = new THREE.Mesh(new THREE.BoxGeometry(.3, .43, .23), standard('#6e9876', .62, { metalness: .2 }));
  tank.position.set(-.19, .02, -.04);
  tank.visible = false;
  bucket.add(tank);
  rig.add(bucket);
  rig.userData.bucket = bucket;
  rig.userData.waterSurface = water;
  rig.userData.spout = spout;
  rig.userData.nozzle = nozzle;
  rig.userData.tank = tank;
  rig.position.set(.45, -.48, -.78);
  rig.rotation.set(-.08, -.14, -.08);
  return rig;
}

export function refreshTerrainVisuals(v) {
  const dummy = new THREE.Object3D();
  const stageLists = [[], [], [], [], []];
  const grassList = [];
  const flowerList = [];
  for (const cell of v.cells) {
    if (cell.stage > 0) stageLists[cell.stage].push(cell);
    if (cell.stage >= 3) {
      const blades = cell.stage === 4 ? 7 : 4;
      for (let i = 0; i < blades; i++) {
        const seed = cell.variation * 50 + i * 17;
        grassList.push({
          x: cell.x + (Math.sin(seed * 14.7) * .42) * TILE_SIZE,
          z: cell.z + (Math.cos(seed * 9.1) * .42) * TILE_SIZE,
          y: terrainHeight(cell.x, cell.z) + .1,
          rot: seed * 2.13,
          scale: .45 + (i % 3) * .18
        });
      }
      if (cell.stage === 4 && Math.round(cell.variation * 13) % 3 === 0) {
        flowerList.push({ x: cell.x + (cell.variation - .5) * 2, z: cell.z - cell.variation * 1.5, y: terrainHeight(cell.x, cell.z) + .28 });
      }
    }
  }

  for (let stage = 1; stage <= 4; stage++) {
    const mesh = v.patches[stage];
    const list = stageLists[stage];
    mesh.count = list.length;
    list.forEach((cell, i) => {
      dummy.position.set(cell.x, terrainHeight(cell.x, cell.z) + .075 + stage * .003, cell.z);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      mesh.setMatrixAt(i, dummy.matrix);
      const color = new THREE.Color(varyStageColor(stage, cell.variation));
      mesh.setColorAt(i, color);
    });
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }

  v.grass.count = Math.min(grassList.length, v.grass.instanceMatrix.count);
  grassList.slice(0, v.grass.count).forEach((b, i) => {
    dummy.position.set(b.x, b.y, b.z);
    dummy.rotation.set(0, b.rot, 0);
    dummy.scale.set(b.scale, b.scale, b.scale);
    dummy.updateMatrix();
    v.grass.setMatrixAt(i, dummy.matrix);
  });
  v.grass.instanceMatrix.needsUpdate = true;

  v.flowers.count = Math.min(flowerList.length, v.flowers.instanceMatrix.count);
  flowerList.slice(0, v.flowers.count).forEach((f, i) => {
    dummy.position.set(f.x, f.y, f.z);
    dummy.rotation.set(0, i * .71, 0);
    dummy.scale.setScalar(.5 + (i % 3) * .18);
    dummy.updateMatrix();
    v.flowers.setMatrixAt(i, dummy.matrix);
  });
  v.flowers.instanceMatrix.needsUpdate = true;
  v.lastVisualUpdate = performance.now();
}

function varyStageColor(stage, variation) {
  const colors = ['#000000', '#8f7857', '#7c704f', '#6d9a54', '#477c49'];
  const color = new THREE.Color(colors[stage]);
  const shift = (variation - .5) * .13;
  color.offsetHSL(shift * .15, shift * .3, shift);
  return color;
}

export function makeMachineModel(type, x, z, layer) {
  const group = new THREE.Group();
  const metal = standard('#778c83', .42, { metalness: .65 });
  const dark = standard('#354c43', .4, { metalness: .55 });
  const green = standard('#9cc879', .55, { metalness: .12 });
  const brass = standard('#c6a76f', .45, { metalness: .55 });
  const add = (geometry, material, px, py, pz, sx = 1, sy = 1, sz = 1) => {
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(px, py, pz);
    mesh.scale.set(sx, sy, sz);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    group.add(mesh);
    return mesh;
  };
  if (type === 'pump') {
    add(new THREE.CylinderGeometry(.7, .78, 1.25, 12), metal, 0, .68, 0);
    add(new THREE.CylinderGeometry(.48, .48, .12, 16), dark, 0, 1.34, 0);
    add(new THREE.TorusGeometry(.55, .075, 8, 16), brass, 0, 1.0, 0).rotation.x = Math.PI / 2;
    add(new THREE.CylinderGeometry(.16, .16, 1.3, 10), green, .72, .9, 0, 1, 1, 1).rotation.z = Math.PI / 2;
    add(new THREE.BoxGeometry(1.8, .18, .18), dark, 0, .16, 0);
    for (let i = 0; i < 3; i++) add(new THREE.BoxGeometry(.18, .5, .18), dark, -.58 + i * .58, .24, 0);
  } else if (type === 'sprinkler') {
    add(new THREE.CylinderGeometry(.22, .34, .7, 10), dark, 0, .35, 0);
    add(new THREE.CylinderGeometry(.12, .12, .82, 10), metal, 0, 1.05, 0);
    add(new THREE.SphereGeometry(.28, 12, 10), green, 0, 1.48, 0);
    for (let i = 0; i < 4; i++) {
      const a = i * Math.PI / 2;
      const arm = add(new THREE.CylinderGeometry(.045, .07, 1.35, 8), metal, Math.cos(a) * .58, 1.53, Math.sin(a) * .58);
      arm.rotation.z = Math.PI / 2;
      arm.rotation.y = -a;
      const nozzle = add(new THREE.SphereGeometry(.1, 8, 8), brass, Math.cos(a) * 1.2, 1.53, Math.sin(a) * 1.2);
    }
  } else if (type === 'tower') {
    add(new THREE.CylinderGeometry(.65, .85, 3.5, 10), metal, 0, 1.8, 0);
    add(new THREE.CylinderGeometry(.92, .82, .28, 12), green, 0, 3.55, 0);
    add(new THREE.CylinderGeometry(.45, .65, .3, 12), brass, 0, 3.75, 0);
    for (let i = 0; i < 4; i++) {
      const brace = add(new THREE.BoxGeometry(.12, 2.9, .12), dark, Math.cos(i * Math.PI / 2) * .72, 1.8, Math.sin(i * Math.PI / 2) * .72);
    }
  } else if (type === 'fertilizer') {
    add(new THREE.CylinderGeometry(.7, .8, 1.35, 12), green, 0, .72, 0);
    add(new THREE.CylinderGeometry(.72, .72, .16, 12), brass, 0, 1.45, 0);
    add(new THREE.ConeGeometry(.55, .65, 10), metal, 0, 1.84, 0);
    add(new THREE.BoxGeometry(.24, .8, .24), dark, .7, .58, 0);
    add(new THREE.SphereGeometry(.12, 10, 8), brass, .7, 1.04, 0);
  } else if (type === 'robot') {
    add(new THREE.BoxGeometry(1.65, .8, 1.1), green, 0, .85, 0);
    add(new THREE.BoxGeometry(.9, .42, .82), metal, 0, 1.43, -.02);
    add(new THREE.SphereGeometry(.12, 12, 10), standard('#b9e6e9', .2, { emissive: '#28535a' }), 0, 1.48, .41);
    for (const side of [-1, 1]) {
      add(new THREE.CylinderGeometry(.32, .32, .22, 12), dark, side * .72, .4, 0).rotation.z = Math.PI / 2;
      add(new THREE.BoxGeometry(.12, .22, .16), brass, side * .72, 1.2, .32);
    }
    add(new THREE.CylinderGeometry(.11, .11, .9, 8), metal, 0, 1.8, -.1);
    add(new THREE.SphereGeometry(.18, 8, 8), brass, 0, 2.25, -.1);
  }
  group.position.set(x, terrainHeight(x, z), z);
  group.rotation.y = Math.random() * Math.PI * 2;
  group.userData.type = type;
  layer.add(group);
  return group;
}

export function spawnSplash(layer, x, y, z) {
  const group = new THREE.Group();
  const mat = new THREE.MeshBasicMaterial({ color: '#8fe0e8', transparent: true, opacity: .8 });
  const count = 10;
  for (let i = 0; i < count; i++) {
    const drop = new THREE.Mesh(new THREE.SphereGeometry(.06 + Math.random() * .045, 7, 6), mat.clone());
    drop.position.set((Math.random() - .5) * .35, .1 + Math.random() * .2, (Math.random() - .5) * .35);
    drop.userData.velocity = new THREE.Vector3((Math.random() - .5) * 2.6, 1.3 + Math.random() * 2.1, (Math.random() - .5) * 2.6);
    drop.userData.life = .55 + Math.random() * .3;
    group.add(drop);
  }
  group.position.set(x, y, z);
  group.userData.life = 1;
  layer.add(group);
  return group;
}

export function updateEffects(layer, dt) {
  for (let i = layer.children.length - 1; i >= 0; i--) {
    const group = layer.children[i];
    group.userData.life -= dt;
    group.children.forEach(drop => {
      if (drop.userData.velocity) {
        drop.position.addScaledVector(drop.userData.velocity, dt);
        drop.userData.velocity.y -= 6.5 * dt;
        drop.material.opacity = Math.max(0, group.userData.life);
      }
    });
    if (group.userData.life <= 0) layer.remove(group);
  }
}

export function animateWorld(world, elapsed, dt) {
  world.water.material.opacity = .91 + Math.sin(elapsed * 1.7) * .025;
  world.water.position.y = .48 + Math.sin(elapsed * 1.3) * .025;
  world.ripples.forEach((ring, i) => {
    const scale = .6 + ((elapsed * .22 + ring.userData.phase) % 1.4);
    ring.scale.setScalar(scale * ring.userData.base / 3.5);
    ring.material.opacity = Math.max(0, .22 - scale * .08);
    ring.position.y = .5 + i * .001;
  });
  const p = world.dust.geometry.attributes.position;
  for (let i = 0; i < p.count; i++) {
    let y = p.getY(i) + dt * (.22 + (i % 7) * .025);
    if (y > 18) y = .7;
    p.setY(i, y);
    p.setX(i, p.getX(i) + Math.sin(elapsed * .25 + i) * dt * .08);
  }
  p.needsUpdate = true;
  updateEffects(world.effectsLayer, dt);
}
