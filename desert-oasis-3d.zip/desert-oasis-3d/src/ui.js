import * as THREE from 'three';
import { EQUIPMENT, MACHINES, ZONES } from './game.js';

const $ = (id) => document.getElementById(id);
const fmt = (n) => Math.floor(Number(n)||0).toLocaleString('en-US');

export class UIController {
  constructor() {
    this.game = null;
    this.panel = null;
    this.shopTab = 'equipment';
    this.toastTimeout = null;
    this.mapTimer = 0;
    this.callbacks = {
      onStarted:() => this.onStarted(),
      onState:(state) => this.onState(state),
      onPrompt:(prompt) => this.onPrompt(prompt),
      onFillProgress:(value,active) => this.onFillProgress(value,active),
      onToast:(message) => this.toast(message),
      onToastEnd:() => this.hideToast(),
      onPlacement:(active,name) => this.onPlacement(active,name),
      onFloatReward:(reward) => this.floatReward(reward),
      onSaved:(ok) => { if (this.panel === 'settings') this.renderPanel(); },
      onTick:(dt) => this.onTick(dt),
      onLockChange:(locked) => this.onLockChange(locked)
    };
    this.bindStaticEvents();
  }

  attach(game) { this.game = game; }

  bindStaticEvents() {
    $('start-button').addEventListener('click', () => this.game?.start());
    $('panel-close').addEventListener('click', () => this.closePanel());
    $('panel-backdrop').addEventListener('click', () => this.closePanel());
    document.querySelectorAll('[data-panel]').forEach(button => button.addEventListener('click', () => { if (button.closest('.pause-actions')) this.hidePause(false); this.openPanel(button.dataset.panel); }));
    $('pause-button').addEventListener('click', () => this.pause());
    $('resume-button').addEventListener('click', () => this.resume());
    $('save-button').addEventListener('click', () => { this.game?.save(); this.toast('Progress saved on this device'); });
    $('panel-content').addEventListener('click', e => this.onPanelClick(e));
    $('panel-content').addEventListener('change', e => this.onPanelChange(e));
    window.addEventListener('beforeunload', () => this.game?.save());
    window.addEventListener('keydown', e => {
      if (!this.playing || e.repeat || e.altKey || e.ctrlKey || e.metaKey) return;
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement || e.target instanceof HTMLTextAreaElement) return;
      const panels = { KeyB:'shop', KeyI:'inventory', KeyM:'map', KeyN:'machines' };
      if (panels[e.code]) { e.preventDefault(); this.openPanel(panels[e.code]); }
    });
    if (window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 680) {
      $('mobile-controls').classList.remove('hidden');
      document.getElementById('game-root').classList.add('touch');
    }
  }

  onStarted() {
    $('start-screen').classList.add('hidden');
    $('hud').classList.remove('hidden');
    this.playing = true;
    this.onState(this.game.getSnapshot());
    this.renderMinimap();
  }

  onLockChange(locked) {
    if (!locked && this.playing && !this.game?.pendingMachine && !this.game?.isPaused && !this.game?.isMobile() && !this.panel) {
      this.pause(true);
    }
  }

  pause(fromEscape = false) {
    if (!this.game || !this.playing) return;
    if (!this.game.isPaused) this.game.pause();
    this.hidePause(false);
    $('pause-overlay').classList.remove('hidden');
    if (!fromEscape && document.pointerLockElement) document.exitPointerLock?.();
  }

  hidePause(resumeGame = false) {
    $('pause-overlay').classList.add('hidden');
    if (resumeGame) this.game?.resume();
  }

  resume() {
    this.hidePause(true);
    this.closePanel();
    if (this.game?.isPaused) this.game.resume();
  }

  openPanel(name) {
    this.panel = name;
    if (name === 'shop') this.shopTab = 'equipment';
    this.renderPanel();
    $('panel-backdrop').classList.remove('hidden');
    $('side-panel').classList.remove('hidden');
    if (document.pointerLockElement) document.exitPointerLock?.();
  }

  closePanel() {
    $('panel-backdrop').classList.add('hidden');
    $('side-panel').classList.add('hidden');
    this.panel = null;
    if (this.game?.isPaused) $('pause-overlay').classList.remove('hidden');
    if (this.playing && !this.game?.isPaused && !this.game?.isMobile() && !this.game?.pendingMachine) this.game.renderer.domElement.requestPointerLock?.();
  }

  renderPanel() {
    if (!this.panel || !this.game) return;
    const state = this.game.getSnapshot();
    const content = $('panel-content');
    let eyebrow = 'OASIS SYSTEMS';
    let title = 'Equipment shop';
    let html = '';
    if (this.panel === 'shop') {
      title = 'Equipment shop';
      eyebrow = 'TOOLS & UPGRADES';
      html = `<div class="tab-row">${[['equipment','Equipment'],['upgrades','Upgrades'],['zones','Regions']].map(([id,label]) => `<button class="tab-button ${this.shopTab===id?'active':''}" data-shop-tab="${id}">${label}</button>`).join('')}</div>`;
      if (this.shopTab === 'equipment') {
        html += `<div class="panel-section-title"><span>WATERING EQUIPMENT</span><small>${state.ownedEquipment.length} / ${EQUIPMENT.length} OWNED</small></div><div class="shop-grid">`;
        html += EQUIPMENT.map(item => {
          const owned = state.ownedEquipment.includes(item.id), equipped = state.equipped === item.id;
          return `<button class="shop-card ${owned?'owned':''} ${equipped?'equipped':''}" data-buy-equipment="${item.id}"><span class="shop-tag">${equipped?'EQUIPPED':owned?'OWNED':''}</span><div class="shop-visual">${item.icon}</div><strong>${item.name}</strong><p>${item.description}</p><div class="shop-card-footer"><span>${owned?'SELECT':`✦ ${fmt(item.price)}`}</span><span>${item.capacity} L</span></div></button>`;
        }).join('');
        html += `</div><div class="panel-note">Every tool changes your first-person equipment, carrying capacity and watering radius. Your upgrades apply to all manual tools.</div>`;
      } else if (this.shopTab === 'upgrades') {
        html += `<div class="panel-section-title"><span>PLAYER & RESTORATION</span><small>LEVEL UP TO 5</small></div><div class="upgrade-list">`;
        html += [
          ['capacity','▤','Bigger Carry Pouch','Increase carried water capacity by 20%.',180,'+20% capacity'],
          ['collection','◴','Faster Collection','Fill your container faster at the pond.',220,'+18% collection speed'],
          ['efficiency','♧','Water Saver','Every pour restores more ground per water unit.',340,'+12% watering efficiency'],
          ['growth','✳','Healthy Soil','Increase the speed of natural plant growth.',420,'+25% growth speed'],
          ['radius','⌁','Wide Spray Nozzle','Increase the effective watering radius.',520,'+15% watering radius'],
          ['speed','↗','Desert Boots','Move faster across dry and restored land.',300,'+8% movement speed']
        ].map(([id,icon,name,desc,base,effect]) => {
          const level = state.upgrades[id]||0, cost = Math.round(base*Math.pow(1.72,level));
          return `<div class="upgrade-row"><div class="upgrade-icon">${icon}</div><div class="upgrade-copy"><strong>${name} <span style="color:#b5d98e">Lv. ${level}/5</span></strong><small>${desc}</small><small style="color:#c7dcae">${effect}</small></div><button class="buy-small" data-buy-upgrade="${id}" ${level>=5||state.coins<cost?'disabled':''}>${level>=5?'MAX':`✦ ${fmt(cost)}`}</button></div>`;
        }).join('');
        html += `</div><div class="panel-note">Upgrade prices increase with each level. Purchase effects are applied immediately.</div>`;
      } else {
        html += `<div class="panel-section-title"><span>EXPAND YOUR WORLD</span><small>${state.unlockedZones.length} / ${ZONES.length} OPEN</small></div><div class="zone-list">`;
        html += ZONES.map(zone => {
          const unlocked = state.unlockedZones.includes(zone.id);
          const enoughPoints = state.restoredCount >= zone.needed;
          const canBuy = !unlocked && enoughPoints && state.coins >= zone.price;
          return `<div class="zone-row ${unlocked?'':'region-locked'}"><div class="zone-icon">${zone.icon}</div><div class="zone-copy"><strong>${zone.name}</strong><small>${zone.description}</small><small style="color:${unlocked?'#b5d98e':'#c8b17e'}">${unlocked?'UNLOCKED':`${zone.needed} restored patches · ${fmt(zone.price)} coins`}</small></div><button class="buy-small" data-buy-zone="${zone.id}" ${unlocked||!canBuy?'disabled':''}>${unlocked?'OPEN':`✦ ${fmt(zone.price)}`}</button></div>`;
        }).join('');
        html += `</div><div class="panel-note">Restoration milestones and coins unlock new land. Locked regions cannot be watered until purchased.</div>`;
      }
    } else if (this.panel === 'machines') {
      title = 'Automation'; eyebrow = 'BUILD YOUR OASIS';
      html = `<div class="panel-section-title"><span>RESTORATION MACHINES</span><small>${state.machines.length} PLACED</small></div><div class="machine-list">`;
      html += MACHINES.map(m => `<div class="machine-row"><div class="machine-icon">${m.icon}</div><div class="machine-copy"><strong>${m.name}</strong><small>${m.description}</small><small style="color:#c0d9a6">${m.detail}</small></div><button class="buy-small" data-place-machine="${m.id}" ${state.coins<m.price?'disabled':''}>✦ ${fmt(m.price)}</button></div>`).join('');
      html += `</div><p class="panel-note">Select a machine, then click a clear patch of ground to place it. Pumps and towers draw water from the central pond. Sprinklers connect to a pump within 32 m. Fertilizer units speed up growth wherever soil is already moist.</p>`;
      if (state.machines.length) {
        html += `<div class="panel-section-title"><span>ACTIVE MACHINES</span><small>${state.machines.length} RUNNING</small></div><div class="inventory-list">`;
        html += state.machines.map(m => { const def=MACHINES.find(x=>x.id===m.type); return `<div class="inventory-row"><div class="inventory-icon">${def?.icon||'⚙'}</div><div class="inventory-copy"><strong>${def?.name||m.type}</strong><small>Level ${m.level||1} · ${Math.round(m.x)}, ${Math.round(m.z)}</small></div><span class="shop-tag">ACTIVE</span></div>`; }).join('');
        html += `</div>`;
      }
    } else if (this.panel === 'inventory') {
      title = 'Inventory'; eyebrow = 'YOUR FIELD KIT';
      html = `<div class="stats-grid"><div class="stat-row"><small>RESTORATION POINTS</small><strong>${fmt(state.restorationPoints)}</strong></div><div class="stat-row"><small>ADVANCED MATERIALS</small><strong>${fmt(state.materials)}</strong></div><div class="stat-row"><small>PATCHES RESTORED</small><strong>${fmt(state.restoredCount)}</strong></div><div class="stat-row"><small>WATER CARRIED</small><strong>${state.water.toFixed(1)} / ${this.game.capacity()}</strong></div></div><div class="panel-section-title"><span>OWNED EQUIPMENT</span><small>${state.ownedEquipment.length} ITEMS</small></div><div class="inventory-list">`;
      html += state.ownedEquipment.map(id => { const item=EQUIPMENT.find(e=>e.id===id); return `<div class="inventory-row"><div class="inventory-icon">${item.icon}</div><div class="inventory-copy"><strong>${item.name}</strong><small>${item.capacity} L capacity · ${item.radius.toFixed(1)}× radius</small></div><button class="buy-small" data-equip="${item.id}" ${state.equipped===item.id?'disabled':''}>${state.equipped===item.id?'EQUIPPED':'EQUIP'}</button></div>`; }).join('');
      html += `</div><div class="panel-note">Restoration materials are earned at every 25th new grass patch. They will be used by advanced crafting systems in future content.</div>`;
    } else if (this.panel === 'map') {
      title = 'Field map'; eyebrow = 'YOUR RESTORATION NETWORK';
      html = `<canvas id="large-map" class="map-large" width="600" height="600"></canvas><div class="map-legend" style="margin-top:12px"><span><i class="legend-player"></i> YOU</span><span><i class="legend-water"></i> POND</span><span><i class="legend-green"></i> RESTORED GROUND</span></div><div class="panel-section-title" style="margin-top:24px"><span>REGION ACCESS</span><small>${state.unlockedZones.length} / ${ZONES.length}</small></div><div class="zone-list">`;
      html += ZONES.map(z => `<div class="zone-row"><div class="zone-icon">${z.icon}</div><div class="zone-copy"><strong>${z.name}</strong><small>${this.stateZoneLabel(z.id)}</small></div><span class="shop-tag">${state.unlockedZones.includes(z.id)?'OPEN':'LOCKED'}</span></div>`).join('');
      html += `</div>`;
    } else if (this.panel === 'settings') {
      title = 'Settings'; eyebrow = 'MAKE YOURSELF AT HOME';
      html = `<div class="panel-section-title"><span>GRAPHICS</span><small>PERFORMANCE</small></div>
        <div class="settings-row"><label>Graphics quality<small>Adjust shadows and rendering scale</small></label><select name="quality"><option value="low" ${state.settings.quality==='low'?'selected':''}>Low · Performance</option><option value="medium" ${state.settings.quality==='medium'?'selected':''}>Medium · Balanced</option><option value="high" ${state.settings.quality==='high'?'selected':''}>High · Quality</option></select></div>
        <div class="settings-row"><label>Frame rate limit<small>Maximum target frame rate</small></label><select name="fps"><option value="30" ${state.settings.fps===30?'selected':''}>30 FPS</option><option value="60" ${state.settings.fps===60?'selected':''}>60 FPS</option><option value="120" ${state.settings.fps===120?'selected':''}>120 FPS</option><option value="0" ${state.settings.fps===0?'selected':''}>Unlimited</option></select></div>
        <div class="panel-section-title" style="margin-top:25px"><span>CONTROLS</span><small>LOOK & FEEL</small></div>
        <div class="settings-row"><label>Mouse sensitivity<small>Camera rotation speed</small></label><input name="sensitivity" type="range" min="0.3" max="2.5" step="0.1" value="${state.settings.sensitivity}" /></div>
        <div class="panel-section-title" style="margin-top:25px"><span>AUDIO</span><small>VOLUME</small></div>
        <div class="settings-row"><label>Sound effects<small>Water, rewards and machines</small></label><input name="sfx" type="range" min="0" max="1" step="0.05" value="${state.settings.sfx}" /></div>
        <div class="settings-row"><label>Ambient sound<small>Soft desert atmosphere</small></label><input name="music" type="range" min="0" max="0.5" step="0.01" value="${state.settings.music}" /></div>
        <div class="panel-section-title" style="margin-top:25px"><span>PROGRESS</span><small>LOCAL SAVE</small></div>
        <button class="buy-small" style="width:100%;padding:12px;margin-bottom:9px" data-save-game> SAVE PROGRESS TO THIS DEVICE </button>
        <button class="buy-small" style="width:100%;padding:12px;background:rgba(180,100,75,.2);color:#e6b7a2;border:1px solid rgba(210,130,100,.25)" data-reset-game> RESET ALL PROGRESS </button>
        <p class="panel-note">Your progress is saved automatically in this browser using local storage. It does not sync between devices or browsers.</p>`;
    }
    $('panel-eyebrow').textContent = eyebrow;
    $('panel-title').textContent = title;
    content.innerHTML = html;
    if (this.panel === 'map') requestAnimationFrame(() => this.drawMap($('large-map')));
  }

  stateZoneLabel(id) {
    const zone=ZONES.find(z=>z.id===id); return zone?.description || '';
  }

  onPanelClick(e) {
    const btn = e.target.closest('button');
    if (!btn || !this.game) return;
    if (btn.dataset.shopTab) { this.shopTab=btn.dataset.shopTab; this.renderPanel(); return; }
    if (btn.dataset.buyEquipment) { this.game.buyEquipment(btn.dataset.buyEquipment); this.renderPanel(); return; }
    if (btn.dataset.equip) { this.game.buyEquipment(btn.dataset.equip); this.renderPanel(); return; }
    if (btn.dataset.buyUpgrade) { this.game.buyUpgrade(btn.dataset.buyUpgrade); this.renderPanel(); return; }
    if (btn.dataset.buyZone) { this.game.buyZone(btn.dataset.buyZone); this.renderPanel(); return; }
    if (btn.dataset.placeMachine) {
      if (this.game.beginMachinePlacement(btn.dataset.placeMachine)) this.closePanel();
      return;
    }
    if (btn.hasAttribute('data-save-game')) { this.game.save(); this.toast('Progress saved on this device'); return; }
    if (btn.hasAttribute('data-reset-game')) {
      if (confirm('Reset all Oasis progress on this browser? This cannot be undone.')) {
        this.game.resetProgress(); this.renderPanel(); this.toast('A fresh desert awaits');
      }
    }
  }

  onPanelChange(e) {
    if (!this.game) return;
    const target = e.target;
    if (target.name === 'quality') {
      this.game.setGraphicsQuality(target.value);
      this.game.state.settings.quality = target.value;
      this.game.save();
    } else if (target.name === 'fps') {
      this.game.state.settings.fps = Number(target.value);
      this.game.save();
    } else if (target.name === 'sensitivity') {
      this.game.state.settings.sensitivity = Number(target.value);
      this.game.save();
    } else if (target.name === 'sfx' || target.name === 'music') {
      this.game.state.settings[target.name] = Number(target.value);
      if (this.game.audio) {
        const node = target.name === 'sfx' ? this.game.audio.master : this.game.audio.music;
        node.gain.setTargetAtTime(Number(target.value), this.game.audio.context.currentTime, .05);
      }
      this.game.save();
    }
  }

  onState(state) {
    if (!this.game) return;
    $('coins-value').textContent = fmt(state.coins);
    $('water-value').textContent = `${state.water.toFixed(1)} / ${state.capacity}`;
    $('restoration-value').textContent = `${state.restoration.toFixed(1)}%`;
    $('tool-name').textContent = state.equipped.name;
    $('tool-description').textContent = state.equipped.description;
    $('tool-capacity').textContent = state.capacity;
    $('tool-radius').textContent = `${state.equipped.radius.toFixed(1)}×`;
    $('tool-illustration').textContent = state.equipped.icon;
    $('objective-title').textContent = state.objective?.title || 'Restore the desert';
    $('objective-description').textContent = state.objective?.description || '';
    $('objective-progress-fill').style.width = `${(state.objective?.value||0)*100}%`;
    $('objective-progress-text').textContent = state.objective?.text || '';
    if (this.panel) this.renderPanel();
  }

  onPrompt(p) {
    if (!p?.show) { $('interaction-prompt').classList.add('hidden'); return; }
    $('interaction-prompt').classList.remove('hidden');
    $('interaction-prompt').querySelector('kbd').textContent = p.key || 'E';
    $('interaction-text').textContent = p.text || 'Interact';
  }

  onFillProgress(value, active) {
    const el = $('water-progress');
    if (active && value > 0) el.classList.remove('hidden');
    else if (value <= 0) el.classList.add('hidden');
    $('water-progress-fill').style.width = `${Math.round(value*100)}%`;
    $('water-progress-percent').textContent = `${Math.round(value*100)}%`;
  }

  onPlacement(active, name) {
    if (active) {
      $('machine-placement-hint').classList.remove('hidden');
      $('machine-placement-hint').textContent = `PLACING ${name?.toUpperCase()||'MACHINE'} · CLICK THE GROUND · ESC TO CANCEL`;
    } else $('machine-placement-hint').classList.add('hidden');
  }

  toast(message) {
    const el = $('action-toast');
    el.textContent = message;
    el.classList.add('visible');
    clearTimeout(this.toastTimeout);
    this.toastTimeout = setTimeout(() => el.classList.remove('visible'), 2200);
  }
  hideToast() { $('action-toast').classList.remove('visible'); }

  floatReward(reward) {
    if (!this.game) return;
    const vector = new THREE.Vector3(reward.x, 1.6, reward.z);
    vector.project(this.game.camera);
    if (vector.z > 1) return;
    const x = (vector.x*.5+.5)*window.innerWidth;
    const y = (-vector.y*.5+.5)*window.innerHeight;
    const el = document.createElement('div');
    el.className = 'toast-float';
    el.textContent = reward.value;
    el.style.left = `${x}px`;
    el.style.top = `${y}px`;
    document.getElementById('game-root').appendChild(el);
    setTimeout(() => el.remove(), 1000);
  }

  onTick(dt) {
    this.mapTimer += dt;
    if (this.mapTimer > .3) {
      this.mapTimer = 0;
      this.renderMinimap();
      if (this.panel === 'map') this.drawMap($('large-map'));
    }
  }

  renderMinimap() { this.drawMap($('minimap')); }

  drawMap(canvas) {
    if (!canvas || !this.game) return;
    const ctx = canvas.getContext('2d');
    const size = canvas.width;
    ctx.clearRect(0,0,size,size);
    ctx.fillStyle = '#b99b6b'; ctx.fillRect(0,0,size,size);
    const scale = size / 220;
    const px = (x) => (x+110)*scale;
    const pz = (z) => (z+110)*scale;
    ctx.fillStyle = '#70b6c1'; ctx.beginPath(); ctx.arc(px(0),pz(0),13.5*scale,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle = 'rgba(234,226,193,.55)'; ctx.lineWidth=Math.max(1,size/300); ctx.beginPath();ctx.arc(px(0),pz(0),16*scale,0,Math.PI*2);ctx.stroke();
    const unlocked = new Set(this.game.state.unlockedZones);
    const cellScale = 5.5*scale;
    for (const cell of this.game.world.cells) {
      if (cell.stage === 0 || !unlocked.has(cell.zone)) continue;
      const colors=['','#8b7454','#877c55','#79a55c','#4e854e'];
      ctx.fillStyle=colors[cell.stage]||'#4e854e';
      ctx.fillRect(px(cell.x)-cellScale/2,pz(cell.z)-cellScale/2,cellScale,cellScale);
    }
    for (const m of this.game.state.machines) {
      ctx.fillStyle='#e6cb8a';ctx.beginPath();ctx.arc(px(m.x),pz(m.z),Math.max(2,size/130),0,Math.PI*2);ctx.fill();
    }
    const pos = this.game.playerPosition;
    const yaw = this.game.yaw;
    ctx.save();ctx.translate(px(pos.x),pz(pos.z));ctx.rotate(-yaw);
    ctx.fillStyle='#fff4d2';ctx.beginPath();ctx.moveTo(0,-size/30);ctx.lineTo(size/55,size/45);ctx.lineTo(-size/55,size/45);ctx.closePath();ctx.fill();ctx.restore();
    ctx.strokeStyle='rgba(250,244,222,.26)';ctx.lineWidth=1;ctx.strokeRect(.5,.5,size-1,size-1);
  }
}
