import { OasisGame } from './game.js';
import { UIController } from './ui.js';

const ui = new UIController();
const game = new OasisGame(document.getElementById('scene-container'), ui.callbacks);
ui.attach(game);

window.oasisGame = game;

// Keep the renderer responsive when the browser tab is restored or resized.
document.addEventListener('visibilitychange', () => {
  if (document.hidden && game.isRunning && !game.isPaused) ui.pause();
});

if (window.matchMedia('(pointer: coarse)').matches) {
  document.getElementById('start-button').textContent = 'Enter the oasis';
}
