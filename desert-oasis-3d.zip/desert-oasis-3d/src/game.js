import * as THREE from 'three';
import { createWorld, terrainHeight, refreshTerrainVisuals, makeMachineModel, spawnSplash, animateWorld, TILE_SIZE, GRID_SIZE, POND_RADIUS, zoneAt } from './world.js';

export const EQUIPMENT = [
  { id:'bucket', name:'Starter Bucket', description:'A humble beginning. One patch at a time.', icon:'▱', capacity:5, radius:1.0, efficiency:1, price:0, kind:'manual' },
  { id:'large-bucket', name:'Reinforced Bucket', description:'Carry more water with every trip.', icon:'▱', capacity:11, radius:1.15, efficiency:1.05, price:160, kind:'manual' },
  { id:'watering-can', name:'Copper Watering Can', description:'A steady pour with a wider reach.', icon:'♧', capacity:18, radius:1.45, efficiency:1.2, price:520, kind:'manual' },
  { id:'sprayer', name:'Pressure Sprayer', description:'A focused fan of water for dry ground.', icon:'⌁', capacity:32, radius:1.8, efficiency:1.35, price:1350, kind:'manual' },
  { id:'hose', name:'Garden Hose', description:'Connect to your supply and cover more land.', icon:'〰', capacity:55, radius:2.25, efficiency:1.6, price:3200, kind:'manual' },
  { id:'tank', name:'Portable Water Tank', description:'Bring an entire reserve to the frontier.', icon:'▥', capacity:100, radius:2.8, efficiency:1.8, price:7600, kind:'manual' },
  { id:'mist-cannon', name:'Mist Cannon', description:'A high-pressure arc for large areas.', icon:'◉', capacity:170, radius:3.7, efficiency:2.2, price:16500, kind:'manual' },
  { id:'restoration-rig', name:'Restoration Rig', description:'Industrial-scale watering equipment.', icon:'▤', capacity:300, radius:4.8, efficiency:2.8, price:42000, kind:'manual' }
];

export const MACHINES = [
  { id:'pump', name:'Pond Water Pump', icon:'◉', price:450, radius:15, rate:1.4, description:'Draws from the central pond and feeds nearby soil.', detail:'1.4 water / sec · 15 m radius' },
  { id:'sprinkler', name:'Rotating Sprinkler', icon:'✳', price:700, radius:12, rate:.9, description:'Automatically waters nearby land when connected to a pump.', detail:'0.9 water / sec · 12 m radius' },
  { id:'tower', name:'Irrigation Tower', icon:'♜', price:2400, radius:23, rate:2.1, description:'Covers a broad circle with balanced irrigation.', detail:'2.1 water / sec · 23 m radius' },
  { id:'fertilizer', name:'Fertilizer Dispenser', icon:'♧', price:1850, radius:18, rate:.75, description:'Improves fertility and speeds up plant growth.', detail:'+0.75 fertility / sec · 18 m radius' },
  { id:'robot', name:'Oasis Restoration Bot', icon:'▣', price:6200, radius:17, rate:1.3, description:'A roaming helper that waters and nurtures the ground.', detail:'1.3 water / sec · 17 m radius' }
];

const UPGRADE_DEFS = [
  { id:'capacity', name:'Bigger Carry Pouch', icon:'▤', description:'Increase carried water capacity by 20%.', base:180, effect:'+20% capacity', max:5 },
  { id:'collection', name:'Faster Collection', icon:'◴', description:'Fill your container faster at the pond.', base:220, effect:'+18% collection speed', max:5 },
  { id:'efficiency', name:'Water Saver', icon:'♧', description:'Every pour restores more ground per water unit.', base:340, effect:'+12% watering efficiency', max:5 },
  { id:'growth', name:'Healthy Soil', icon:'✳', description:'Increase the speed of natural plant growth.', base:420, effect:'+25% growth speed', max:5 },
  { id:'radius', name:'Wide Spray Nozzle', icon:'⌁', description:'Increase the effective watering radius.', base:520, effect:'+15% watering radius', max:5 },
  { id:'speed', name:'Desert Boots', icon:'↗', description:'Move faster across restored and dry ground.', base:300, effect:'+8% movement speed', max:5 }
];

const ZONES = [
  { id:'starting', name:'Starting Desert', icon:'☼', price:0, needed:0, description:'The first stretch of land around the oasis pond.' },
  { id:'palm', name:'Palm Forest', icon:'♧', price:1200, needed:28, description:'A sheltered grove of palms and warm, rich soil.' },
  { id:'flower', name:'Flower Valley', icon:'✿', price:3900, needed:100, description:'A broad valley where wildflowers can take root.' },
  { id:'valley', name:'Emerald Basin', icon:'◈', price:9200, needed:260, description:'A low basin ready for deep-rooted vegetation.' },
  { id:'jungle', name:'The Green Frontier', icon:'♣', price:24000, needed:650, description:'The final step toward a thriving green ecosystem.' }
];

const DEFAULT_UPGRADES = { capacity:0, collection:0, efficiency:0, growth:0, radius:0, speed:0 };
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const num = (v, fallback = 0) => Number.isFinite(Number(v)) ? Number(v) : fallback;

function defaultState() {
  return {
    coins:0, restorationPoints:0, materials:0, restoredCount:0,
    water:0, firstWatered:false, firstGrass:false, questStage:0,
    ownedEquipment:['bucket'], equipped:'bucket',
    upgrades:{...DEFAULT_UPGRADES}, machines:[], unlockedZones:['starting'],
    totalWatered:0, totalPlayTime:0, totalCoinsEarned:0, lastSaved:0,
    settings:{quality:'high', sensitivity:1, sfx:0.7, music:0.18, fps:60},
    tiles:[]
  };
}

export class OasisGame {
  constructor(container, callbacks = {}) {
    this.container = container;
    this.callbacks = callbacks;
    this.state = defaultState();
    this.clock = new THREE.Clock();
    this.elapsed = 0;
    this.isRunning = false;
    this.isPaused = false;
    this.isLocked = false;
    this.isPouring = false;
    this.fillHeld = false;
    this.fillProgress = 0;
    this.pourCooldown = 0;
    this.visualDirty = true;
    this.visualTimer = 0;
    this.machineTimer = 0;
    this.saveTimer = 0;
    this.toastTimer = 0;
    this.lastToast = '';
    this.pendingMachine = null;
    this.pendingMachineCost = 0;
    this.yaw = 0;
    this.pitch = 0;
    this.verticalVelocity = 0;
    this.keys = new Set();
    this.touchMove = { x:0, y:0 };
    this.mouseDelta = { x:0, y:0 };
    this.raycaster = new THREE.Raycaster();
    this.raycaster.far = 34;
    this.centerNdc = new THREE.Vector2(0, 0);
    this.cellLookup = new Map();
    this.audio = null;
    this.ambientNodes = null;
    this.machineGroups = [];
    this.machineGlow = [];
    this.fpsSamples = [];
    this.initScene();
    this.load();
    this.rebuildMachineModels();
    this.setupInputs();
    this.setupAudio();
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(this.container);
    this.resize();
    this.updateViewmodel();
    this.updateCallbacks();
  }

  initScene() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#cfbea0');
    this.scene.fog = new THREE.Fog('#cfbea0', 80, 205);
    this.camera = new THREE.PerspectiveCamera(76, 1, .1, 280);
    this.camera.position.set(0, 1.72, 39);
    this.camera.rotation.order = 'YXZ';
    this.scene.add(this.camera);

    this.hemi = new THREE.HemisphereLight('#fff2d9', '#75583a', 2.0);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight('#ffe1a7', 2.55);
    this.sun.position.set(-48, 72, 32);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1024, 1024);
    this.sun.shadow.camera.left = -95;
    this.sun.shadow.camera.right = 95;
    this.sun.shadow.camera.top = 95;
    this.sun.shadow.camera.bottom = -95;
    this.sun.shadow.bias = -.00025;
    this.scene.add(this.sun);
    this.ambient = new THREE.AmbientLight('#c7d9b5', .28);
    this.scene.add(this.ambient);

    this.renderer = new THREE.WebGLRenderer({ antialias:true, alpha:false, powerPreference:'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    this.renderer.setSize(this.container.clientWidth || innerWidth, this.container.clientHeight || innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.domElement.id = 'game-canvas';
    this.renderer.domElement.setAttribute('aria-label','3D desert world. Click to look around and water.');
    this.container.appendChild(this.renderer.domElement);

    this.world = createWorld(this.scene);
    this.placementPreview = new THREE.Group();
    const previewDisk = new THREE.Mesh(new THREE.CircleGeometry(1, 48), new THREE.MeshBasicMaterial({ color:'#a9df79', transparent:true, opacity:.11, depthWrite:false, side:THREE.DoubleSide }));
    previewDisk.rotation.x = -Math.PI/2;
    previewDisk.position.y = .03;
    const previewRing = new THREE.Mesh(new THREE.RingGeometry(.94, 1, 48), new THREE.MeshBasicMaterial({ color:'#c5ee91', transparent:true, opacity:.82, side:THREE.DoubleSide, depthWrite:false }));
    previewRing.rotation.x = -Math.PI/2;
    previewRing.position.y = .07;
    this.placementPreview.add(previewDisk, previewRing);
    this.placementPreview.visible = false;
    this.placementPreview.userData.parts = [previewDisk, previewRing];
    this.scene.add(this.placementPreview);
    this.world.viewmodel.visible = false;
    this.camera.add(this.world.viewmodel);
    this.playerPosition = new THREE.Vector3(0, 0, 39);
    this.camera.position.set(0, terrainHeight(0, 39) + 1.72, 39);

    this.cellLookup.clear();
    this.world.cells.forEach(cell => this.cellLookup.set(cell.id, cell));
    this.cellIndexOffset = (GRID_SIZE - 1) / 2;
    this.rebuildTerrainVisuals();
    this.setGraphicsQuality('high');
  }

  resize() {
    const w = Math.max(1, this.container.clientWidth || window.innerWidth);
    const h = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
    const maxDpr = this.state?.settings?.quality === 'low' ? 1 : this.state?.settings?.quality === 'medium' ? 1.25 : 1.6;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxDpr));
  }

  setupInputs() {
    const canvas = this.renderer.domElement;
    this.onKeyDown = (e) => {
      if (['KeyW','KeyA','KeyS','KeyD','ShiftLeft','ShiftRight','Space','KeyE','Escape'].includes(e.code)) e.preventDefault();
      if (e.code === 'Escape') {
        if (this.pendingMachine) this.cancelMachinePlacement();
        else if (this.isLocked) document.exitPointerLock?.();
        else this.callbacks.onPause?.();
      }
      if (e.code === 'KeyE' && !this.keys.has('KeyE')) this.fillHeld = true;
      this.keys.add(e.code);
    };
    this.onKeyUp = (e) => {
      this.keys.delete(e.code);
      if (e.code === 'KeyE') this.fillHeld = false;
    };
    this.onMouseMove = (e) => {
      if (!this.isLocked || this.isPaused) return;
      const sensitivity = this.state.settings.sensitivity || 1;
      this.yaw -= e.movementX * .0021 * sensitivity;
      this.pitch -= e.movementY * .0021 * sensitivity;
      this.pitch = clamp(this.pitch, -1.45, 1.45);
      this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
    };
    this.onPointerLock = () => {
      this.isLocked = document.pointerLockElement === canvas;
      if (!this.isLocked) this.isPouring = false;
      this.callbacks.onLockChange?.(this.isLocked);
    };
    this.onMouseDown = (e) => {
      if (e.button !== 0 || this.isPaused || !this.isRunning) return;
      if (this.pendingMachine) {
        this.placePendingMachine();
        return;
      }
      if (!this.isLocked && !this.isMobile()) {
        canvas.requestPointerLock?.();
        return;
      }
      this.isPouring = true;
      this.sfx('equip');
    };
    this.onMouseUp = (e) => { if (e.button === 0) this.isPouring = false; };
    this.onContext = (e) => e.preventDefault();
    window.addEventListener('keydown', this.onKeyDown, { passive:false });
    window.addEventListener('keyup', this.onKeyUp);
    document.addEventListener('mousemove', this.onMouseMove);
    document.addEventListener('pointerlockchange', this.onPointerLock);
    canvas.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
    canvas.addEventListener('contextmenu', this.onContext);
    window.addEventListener('blur', () => { this.isPouring = false; this.keys.clear(); this.fillHeld = false; });

    const stick = document.getElementById('mobile-stick');
    if (stick) {
      let active = false;
      const update = (e) => {
        const rect = stick.getBoundingClientRect();
        const dx = e.clientX - (rect.left + rect.width/2);
        const dy = e.clientY - (rect.top + rect.height/2);
        const max = rect.width * .34;
        const len = Math.hypot(dx, dy) || 1;
        const k = Math.min(1, max / len);
        this.touchMove.x = dx / max * k;
        this.touchMove.y = dy / max * k;
        stick.firstElementChild.style.transform = `translate(${this.touchMove.x*25}px,${this.touchMove.y*25}px)`;
      };
      stick.addEventListener('pointerdown', e => { active = true; stick.setPointerCapture(e.pointerId); update(e); });
      stick.addEventListener('pointermove', e => { if (active) update(e); });
      const end = () => { active=false; this.touchMove={x:0,y:0}; stick.firstElementChild.style.transform=''; };
      stick.addEventListener('pointerup', end); stick.addEventListener('pointercancel', end);
    }
    const touchButton = (id, down, up = down) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('pointerdown', e => { e.preventDefault(); down(); });
      el.addEventListener('pointerup', e => { e.preventDefault(); up(false); });
      el.addEventListener('pointercancel', () => up(false));
      el.addEventListener('pointerleave', () => up(false));
    };
    touchButton('mobile-interact', () => { this.fillHeld=true; }, () => { this.fillHeld=false; });
    touchButton('mobile-pour', () => { this.isPouring=true; }, () => { this.isPouring=false; });
    touchButton('mobile-jump', () => { this.jump(); });
    let touchLook = null;
    canvas.addEventListener('touchstart', e => {
      if (e.touches.length === 1 && e.touches[0].clientX > window.innerWidth * .35) touchLook = {x:e.touches[0].clientX,y:e.touches[0].clientY};
    }, {passive:true});
    canvas.addEventListener('touchmove', e => {
      if (!touchLook) return;
      const t = [...e.touches].find(t => t.clientX > window.innerWidth * .35);
      if (!t) return;
      const dx=t.clientX-touchLook.x,dy=t.clientY-touchLook.y;
      this.yaw -= dx*.004*(this.state.settings.sensitivity||1);
      this.pitch=clamp(this.pitch-dy*.004*(this.state.settings.sensitivity||1),-1.4,1.4);
      this.camera.rotation.set(this.pitch,this.yaw,0,'YXZ');
      touchLook={x:t.clientX,y:t.clientY};
    },{passive:true});
    canvas.addEventListener('touchend',()=>touchLook=null,{passive:true});
  }

  isMobile() { return window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 680; }

  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.isPaused = false;
    this.world.viewmodel.visible = true;
    this.audio?.context?.resume?.();
    if (!this.isMobile()) this.renderer.domElement.requestPointerLock?.();
    this.callbacks.onStarted?.();
    this.clock.start();
    this.animate();
  }

  pause() {
    this.isPaused = true;
    this.isPouring = false;
    this.fillHeld = false;
    if (document.pointerLockElement) document.exitPointerLock?.();
  }

  resume() {
    this.isPaused = false;
    this.clock.start();
    if (!this.isMobile()) this.renderer.domElement.requestPointerLock?.();
  }

  animate() {
    if (!this.isRunning) return;
    requestAnimationFrame(() => this.animate());
    const fpsLimit = this.state.settings.fps || 0;
    const now = performance.now();
    if (fpsLimit > 0 && this.lastFrameAt && now - this.lastFrameAt < 1000 / fpsLimit - 1) return;
    this.lastFrameAt = now;
    if (this.isPaused) {
      this.renderer.render(this.scene, this.camera);
      return;
    }
    const dt = Math.min(.04, this.clock.getDelta() || 0.016);
    this.elapsed += dt;
    this.update(dt);
    this.renderer.render(this.scene, this.camera);
  }

  update(dt) {
    this.state.totalPlayTime += dt;
    this.updateMovement(dt);
    this.updatePlacementPreview();
    this.updateInteraction(dt);
    this.updateTerrain(dt);
    this.updateMachines(dt);
    this.updateViewmodel(dt);
    animateWorld(this.world, this.elapsed, dt);
    this.updateToast(dt);
    this.saveTimer += dt;
    if (this.saveTimer > 15) { this.saveTimer = 0; this.save(); }
    this.visualTimer += dt;
    if (this.visualDirty && this.visualTimer > .15) {
      refreshTerrainVisuals(this.world.terrainVisuals);
      this.visualDirty = false;
      this.visualTimer = 0;
    }
    this.callbacks.onTick?.(dt);
  }

  updateMovement(dt) {
    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const move = new THREE.Vector3();
    const keyForward = (this.keys.has('KeyW') ? 1 : 0) - (this.keys.has('KeyS') ? 1 : 0) - this.touchMove.y;
    const keyRight = (this.keys.has('KeyD') ? 1 : 0) - (this.keys.has('KeyA') ? 1 : 0) + this.touchMove.x;
    move.addScaledVector(forward, keyForward).addScaledVector(right, keyRight);
    if (move.lengthSq() > 1) move.normalize();
    const sprint = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight');
    const speedLevel = this.state.upgrades.speed || 0;
    const speed = (sprint ? 10.6 : 6.6) * (1 + speedLevel * .08);
    this.playerPosition.addScaledVector(move, speed * dt);
    this.playerPosition.x = clamp(this.playerPosition.x, -105, 105);
    this.playerPosition.z = clamp(this.playerPosition.z, -105, 105);
    if (this.keys.has('Space') && this.onGround) this.jump();
    this.verticalVelocity -= 18 * dt;
    const floor = terrainHeight(this.playerPosition.x, this.playerPosition.z) + 1.72;
    this.camera.position.set(this.playerPosition.x, this.camera.position.y + this.verticalVelocity * dt, this.playerPosition.z);
    if (this.camera.position.y <= floor) {
      this.camera.position.y = floor;
      this.verticalVelocity = 0;
      this.onGround = true;
    } else this.onGround = false;
    this.world.player.position.copy(this.playerPosition);
  }

  jump() {
    if (!this.onGround) return;
    this.verticalVelocity = 7.5;
    this.onGround = false;
    this.sfx('jump');
  }

  updatePlacementPreview() {
    if (!this.pendingMachine) {
      if (this.placementPreview) this.placementPreview.visible = false;
      return;
    }
    this.raycaster.setFromCamera(this.centerNdc, this.camera);
    const hits = this.raycaster.intersectObject(this.world.ground, false);
    if (!hits.length) { this.placementPreview.visible = false; return; }
    const p = hits[0].point;
    const def = MACHINES.find(m => m.id === this.pendingMachine);
    if (!def) return;
    const distance = Math.hypot(p.x-this.playerPosition.x,p.z-this.playerPosition.z);
    const zone = zoneAt(p.x,p.z);
    const valid = distance <= 24 && Math.hypot(p.x,p.z) >= POND_RADIUS + 3 && this.state.unlockedZones.includes(zone) && !this.state.machines.some(m => Math.hypot(m.x-p.x,m.z-p.z) < 5.5);
    this.placementPreview.visible = true;
    this.placementPreview.position.set(p.x, terrainHeight(p.x,p.z)+.12, p.z);
    this.placementPreview.scale.set(def.radius, 1, def.radius);
    const color = valid ? '#bce98c' : '#e28b70';
    this.placementPreview.userData.parts.forEach((part, i) => {
      part.material.color.set(color);
      part.material.opacity = i === 0 ? (valid ? .1 : .15) : (valid ? .82 : .9);
    });
  }

  updateInteraction(dt) {
    const pondDistance = Math.hypot(this.playerPosition.x, this.playerPosition.z);
    const nearPond = pondDistance < POND_RADIUS + 4.5;
    if (nearPond && this.state.water < this.capacity()) {
      this.callbacks.onPrompt?.({show:true,key:'E',text:'Hold to collect water'});
      if (this.fillHeld) {
        this.fillProgress = Math.min(1, this.fillProgress + dt * .72 * (1 + (this.state.upgrades.collection||0) * .18));
        if (this.fillProgress >= 1) {
          const added = Math.min(this.capacity() - this.state.water, 2.1 + (this.state.upgrades.collection||0) * .4);
          this.state.water += added;
          this.fillProgress = 0;
          this.callbacks.onToast?.(`Bucket filled · +${added.toFixed(1)} water`);
          this.sfx('collect');
          this.updateCallbacks();
        }
        this.callbacks.onFillProgress?.(this.fillProgress, true);
      } else {
        this.fillProgress = Math.max(0, this.fillProgress - dt * .75);
        this.callbacks.onFillProgress?.(this.fillProgress, false);
      }
    } else {
      this.callbacks.onPrompt?.({show:false});
      this.fillProgress = Math.max(0, this.fillProgress - dt * 1.3);
      this.callbacks.onFillProgress?.(this.fillProgress, false);
    }
    if (this.isPouring && !this.pendingMachine) {
      this.pourCooldown -= dt;
      if (this.pourCooldown <= 0) {
        this.pourCooldown = .38;
        this.pourWater();
      }
    } else this.pourCooldown = Math.min(this.pourCooldown, 0);
  }

  capacity() {
    const item = EQUIPMENT.find(e => e.id === this.state.equipped) || EQUIPMENT[0];
    return Math.round(item.capacity * (1 + (this.state.upgrades.capacity||0) * .2));
  }
  equippedTool() { return EQUIPMENT.find(e => e.id === this.state.equipped) || EQUIPMENT[0]; }

  pourWater() {
    if (this.state.water <= .05) {
      this.callbacks.onToast?.('Your container is empty · return to the pond');
      this.sfx('empty');
      this.isPouring = false;
      return;
    }
    this.raycaster.setFromCamera(this.centerNdc, this.camera);
    const hits = this.raycaster.intersectObject(this.world.ground, false);
    if (!hits.length) return;
    const hit = hits[0];
    const p = hit.point;
    const dist = Math.hypot(p.x - this.playerPosition.x, p.z - this.playerPosition.z);
    if (dist > 30) return;
    if (Math.hypot(p.x, p.z) < POND_RADIUS + 1.3) {
      this.callbacks.onToast?.('Aim at dry ground, not the pond');
      return;
    }
    const gx = Math.round(p.x / TILE_SIZE + this.cellIndexOffset);
    const gz = Math.round(p.z / TILE_SIZE + this.cellIndexOffset);
    const cell = this.cellLookup.get(`${gx}:${gz}`);
    if (!cell) return;
    if (!this.state.unlockedZones.includes(cell.zone)) {
      const zone = ZONES.find(z => z.id === cell.zone);
      this.callbacks.onToast?.(`${zone?.name || 'This region'} is locked · open the map to unlock it`);
      return;
    }
    const tool = this.equippedTool();
    const upgradeRadius = 1 + (this.state.upgrades.radius||0) * .15;
    const radius = tool.radius * upgradeRadius;
    const waterCost = Math.max(.22, 1 / (tool.efficiency * (1 + (this.state.upgrades.efficiency||0) * .12)));
    if (this.state.water < waterCost) {
      this.callbacks.onToast?.('Not enough water · refill at the pond');
      return;
    }
    this.state.water = Math.max(0, this.state.water - waterCost);
    let watered = 0;
    for (const target of this.world.cells) {
      if (target.zone !== 'starting' && !this.state.unlockedZones.includes(target.zone)) continue;
      const d = Math.hypot(target.x - cell.x, target.z - cell.z) / TILE_SIZE;
      if (d > radius) continue;
      const strength = Math.max(.18, 1 - d / (radius + .4));
      target.reserve = Math.min(24, target.reserve + 3.1 * strength * tool.efficiency);
      target.moisture = clamp(target.moisture + 48 * strength * tool.efficiency, 0, 100);
      target.fertility = clamp(target.fertility + 7.5 * strength, 0, 100);
      target.growth = clamp(target.growth + .075 * strength, 0, 1);
      const oldStage = target.stage;
      target.stage = this.getCellStage(target);
      if (target.stage > oldStage) this.visualDirty = true;
      watered++;
    }
    this.state.totalWatered += watered;
    this.state.firstWatered = true;
    this.state.coins += 1 + Math.max(0, watered - 1) * .5;
    this.state.totalCoinsEarned += 1 + Math.max(0, watered - 1) * .5;
    spawnSplash(this.world.effectsLayer, p.x, terrainHeight(p.x,p.z) + .1, p.z);
    this.sfx('pour');
    this.updateQuest();
    this.updateCallbacks();
    this.callbacks.onWatered?.({x:p.x,z:p.z,count:watered});
  }

  getCellStage(cell) {
    if (cell.growth >= .72 && cell.fertility >= 50) return 4;
    if (cell.growth >= .28 && cell.fertility >= 22) return 3;
    if (cell.fertility >= 12 && cell.moisture >= 28) return 2;
    if (cell.moisture > 0) return 1;
    return 0;
  }

  updateTerrain(dt) {
    let changed = false;
    const growthMultiplier = 1 + (this.state.upgrades.growth||0) * .25;
    for (const cell of this.world.cells) {
      if (cell.reserve > 0) {
        const used = Math.min(cell.reserve, dt * .28);
        cell.reserve -= used;
        cell.moisture = clamp(cell.moisture + used * 3.4, 0, 100);
        cell.fertility = clamp(cell.fertility + used * .9, 0, 100);
      } else if (cell.moisture > 0) {
        cell.moisture = Math.max(0, cell.moisture - dt * .16);
      }
      if (cell.moisture > 10) {
        cell.fertility = clamp(cell.fertility + dt * .35 * growthMultiplier, 0, 100);
        if (cell.fertility > 10) cell.growth = clamp(cell.growth + dt * .018 * growthMultiplier * (cell.fertility / 50), 0, 1);
      } else if (cell.growth > 0) {
        cell.growth = Math.max(0, cell.growth - dt * .0004);
      }
      const next = this.getCellStage(cell);
      if (next !== cell.stage) {
        const previous = cell.stage;
        cell.stage = next;
        changed = true;
        if (next >= 3 && previous < 3 && !cell.rewarded) {
          cell.rewarded = true;
          this.state.firstGrass = true;
          this.state.restoredCount++;
          this.state.restorationPoints += 1;
          this.state.coins += 12;
          this.state.totalCoinsEarned += 12;
          if (this.state.restoredCount % 25 === 0) this.state.materials++;
          this.callbacks.onFloatReward?.({x:cell.x,z:cell.z,value:'+12 ✦'});
          this.sfx('grow');
          this.updateQuest();
        }
      }
    }
    if (changed) {
      this.visualDirty = true;
      this.updateCallbacks();
    }
  }

  updateMachines(dt) {
    this.machineTimer += dt;
    if (this.machineTimer < .5) return;
    const step = this.machineTimer;
    this.machineTimer = 0;
    if (!this.state.machines.length) return;
    const pumps = this.state.machines.filter(m => m.type === 'pump' || m.type === 'tower' || m.type === 'robot');
    for (const machine of this.state.machines) {
      const def = MACHINES.find(m => m.id === machine.type);
      if (!def) continue;
      const group = this.machineGroups.find(g => g.userData.machineId === machine.id);
      if (group) {
        group.rotation.y += step * (machine.type === 'sprinkler' ? 1.1 : .18);
        group.position.y = terrainHeight(machine.x, machine.z) + Math.sin(this.elapsed * 1.6 + machine.x) * .035;
      }
      if (machine.type === 'fertilizer') {
        for (const cell of this.world.cells) {
          if (Math.hypot(cell.x-machine.x,cell.z-machine.z) > def.radius || cell.moisture < 5) continue;
          cell.fertility = clamp(cell.fertility + step * def.rate * .5, 0, 100);
          cell.growth = clamp(cell.growth + step * .012, 0, 1);
        }
        continue;
      }
      const connected = machine.type === 'pump' || machine.type === 'tower' || pumps.some(p => Math.hypot(p.x-machine.x,p.z-machine.z) < 32);
      if (!connected) continue;
      for (const cell of this.world.cells) {
        const d = Math.hypot(cell.x-machine.x, cell.z-machine.z);
        if (d > def.radius || !this.state.unlockedZones.includes(cell.zone)) continue;
        const intensity = Math.max(.08, 1-d/def.radius);
        const rate = def.rate * step * .23 * intensity;
        cell.reserve = Math.min(24, cell.reserve + rate);
        cell.moisture = clamp(cell.moisture + rate * 3.2, 0, 100);
        cell.fertility = clamp(cell.fertility + rate * .9, 0, 100);
        cell.growth = clamp(cell.growth + rate * .018, 0, 1);
        const stage = this.getCellStage(cell);
        if (stage !== cell.stage) {
          const previous = cell.stage;
          cell.stage = stage;
          this.visualDirty = true;
          if (stage >= 3 && previous < 3 && !cell.rewarded) {
            cell.rewarded = true;
            this.state.firstGrass = true;
            this.state.restoredCount++;
            this.state.restorationPoints++;
            this.state.coins += 12;
            this.state.totalCoinsEarned += 12;
            if (this.state.restoredCount % 25 === 0) this.state.materials++;
            this.callbacks.onFloatReward?.({x:cell.x,z:cell.z,value:'+12 ✦'});
          }
        }
      }
    }
    this.updateQuest();
    this.updateCallbacks();
  }

  getRestorationPercent() {
    return this.state.restoredCount / Math.max(1, this.world.cells.filter(c => this.state.unlockedZones.includes(c.zone)).length) * 100;
  }

  buyEquipment(id) {
    const item = EQUIPMENT.find(e => e.id === id);
    if (!item) return false;
    if (this.state.ownedEquipment.includes(id)) {
      this.state.equipped = id;
      this.updateViewmodel();
      this.sfx('equip');
      this.callbacks.onToast?.(`${item.name} equipped`);
      this.updateCallbacks();
      this.save();
      return true;
    }
    if (this.state.coins < item.price) return this.callbacks.onToast?.('Not enough coins yet'), false;
    this.state.coins -= item.price;
    this.state.ownedEquipment.push(id);
    this.state.equipped = id;
    this.updateViewmodel();
    this.sfx('purchase');
    this.callbacks.onToast?.(`${item.name} purchased and equipped`);
    this.updateCallbacks();
    this.save();
    return true;
  }

  buyUpgrade(id) {
    const def = UPGRADE_DEFS.find(u => u.id === id);
    if (!def) return false;
    const level = this.state.upgrades[id] || 0;
    if (level >= def.max) return this.callbacks.onToast?.('Upgrade fully upgraded'), false;
    const cost = Math.round(def.base * Math.pow(1.72, level));
    if (this.state.coins < cost) return this.callbacks.onToast?.('Not enough coins yet'), false;
    this.state.coins -= cost;
    this.state.upgrades[id] = level + 1;
    this.sfx('purchase');
    this.callbacks.onToast?.(`${def.name} · level ${level+1}`);
    this.updateViewmodel();
    this.updateCallbacks();
    this.save();
    return true;
  }

  beginMachinePlacement(id) {
    const def = MACHINES.find(m => m.id === id);
    if (!def) return false;
    if (this.state.coins < def.price) return this.callbacks.onToast?.('Not enough coins to build this machine'), false;
    this.pendingMachine = id;
    this.pendingMachineCost = def.price;
    this.callbacks.onPlacement?.(true, def.name);
    this.callbacks.onToast?.(`Place ${def.name} on the ground`);
    if (document.pointerLockElement) document.exitPointerLock?.();
    return true;
  }

  placePendingMachine() {
    if (!this.pendingMachine) return;
    this.raycaster.setFromCamera(this.centerNdc, this.camera);
    const hits = this.raycaster.intersectObject(this.world.ground, false);
    if (!hits.length) return;
    const p = hits[0].point;
    if (Math.hypot(p.x-this.playerPosition.x,p.z-this.playerPosition.z) > 24) return this.callbacks.onToast?.('Move closer to place the machine');
    if (Math.hypot(p.x,p.z) < POND_RADIUS + 3) return this.callbacks.onToast?.('Keep the pond clear');
    const zone = zoneAt(p.x,p.z);
    if (!this.state.unlockedZones.includes(zone)) return this.callbacks.onToast?.('Unlock this region first');
    if (this.state.machines.some(m => Math.hypot(m.x-p.x,m.z-p.z) < 5.5)) return this.callbacks.onToast?.('There is not enough space here');
    if (this.state.coins < this.pendingMachineCost) return this.callbacks.onToast?.('Not enough coins');
    const type = this.pendingMachine;
    const def = MACHINES.find(m => m.id === type);
    this.state.coins -= this.pendingMachineCost;
    const machine = { id:`m-${Date.now()}-${Math.floor(Math.random()*1000)}`, type, x:p.x, z:p.z, level:1 };
    this.state.machines.push(machine);
    const group = makeMachineModel(type, p.x, p.z, this.world.machineLayer);
    group.userData.machineId = machine.id;
    this.machineGroups.push(group);
    this.pendingMachine = null;
    this.pendingMachineCost = 0;
    this.placementPreview.visible = false;
    this.callbacks.onPlacement?.(false);
    this.callbacks.onToast?.(`${def.name} connected to the oasis`);
    this.sfx('purchase');
    this.updateQuest();
    this.updateCallbacks();
    this.save();
    if (this.isMobile()) this.callbacks.onPrompt?.({show:false});
    else this.renderer.domElement.requestPointerLock?.();
  }

  cancelMachinePlacement() {
    if (!this.pendingMachine) return;
    const type = this.pendingMachine;
    this.pendingMachine = null;
    this.pendingMachineCost = 0;
    this.placementPreview.visible = false;
    this.callbacks.onPlacement?.(false);
    this.callbacks.onToast?.('Machine placement cancelled');
    if (!this.isMobile() && this.isRunning) this.renderer.domElement.requestPointerLock?.();
  }

  buyZone(id) {
    const zone = ZONES.find(z => z.id === id);
    if (!zone || this.state.unlockedZones.includes(id)) return false;
    if (this.state.restoredCount < zone.needed) return this.callbacks.onToast?.(`Restore ${zone.needed} patches to unlock ${zone.name}`), false;
    if (this.state.coins < zone.price) return this.callbacks.onToast?.('Not enough coins to unlock this region'), false;
    this.state.coins -= zone.price;
    this.state.unlockedZones.push(id);
    this.sfx('unlock');
    this.callbacks.onToast?.(`${zone.name} unlocked · new land awaits`);
    this.updateCallbacks();
    this.save();
    return true;
  }

  updateQuest() {
    const s = this.state;
    const old = s.questStage;
    if (s.questStage === 0 && s.water >= 1) s.questStage = 1;
    if (s.questStage === 1 && s.firstWatered) s.questStage = 2;
    if (s.questStage === 2 && s.restoredCount >= 5) s.questStage = 3;
    if (s.questStage === 3 && s.ownedEquipment.length >= 2) s.questStage = 4;
    if (s.questStage === 4 && s.machines.length >= 1) s.questStage = 5;
    if (s.questStage > old) {
      const messages = ['','A fresh start · water collected','A seed of change · first ground watered','Green is growing · 5 patches restored','A better tool · equipment upgraded','Self-sustaining · first machine placed'];
      this.callbacks.onToast?.(messages[s.questStage] || 'New milestone reached');
      this.state.coins += 45;
      this.state.totalCoinsEarned += 45;
      this.sfx('unlock');
    }
  }

  getObjective() {
    const s = this.state;
    const objectives = [
      { title:'Find the water source', description:'Walk to the central pond and collect a bucket of water.', value:Math.min(1,s.water/this.capacity()), text:`${Math.floor(s.water)} / ${this.capacity()}` },
      { title:'Give the ground a drink', description:'Aim at a dry patch and hold the left mouse button to pour.', value:s.firstWatered?1:0, text:s.firstWatered?'1 / 1':'0 / 1' },
      { title:'Bring the first green', description:'Keep watering until five patches begin to grow grass.', value:Math.min(1,s.restoredCount/5), text:`${Math.min(s.restoredCount,5)} / 5` },
      { title:'Upgrade your equipment', description:'Earn coins from restored ground and buy a better watering tool.', value:Math.min(1,(s.ownedEquipment.length-1)/1), text:s.ownedEquipment.length>1?'1 / 1':'0 / 1' },
      { title:'Build your first machine', description:'Place a pump or sprinkler and let the oasis grow by itself.', value:Math.min(1,s.machines.length/1), text:`${Math.min(s.machines.length,1)} / 1` },
      { title:'Expand the oasis', description:'Unlock a new region and keep restoring the desert.', value:Math.min(1,(s.unlockedZones.length-1)/1), text:`${s.unlockedZones.length-1} / 1` }
    ];
    return objectives[Math.min(s.questStage,objectives.length-1)];
  }

  updateCallbacks() {
    const tool = this.equippedTool();
    this.callbacks.onState?.({
      coins:Math.floor(this.state.coins),
      water:this.state.water,
      capacity:this.capacity(),
      restored:this.state.restoredCount,
      restoration:this.getRestorationPercent(),
      restorationPoints:this.state.restorationPoints,
      materials:this.state.materials,
      equipped:tool,
      objective:this.getObjective(),
      equipmentCount:this.state.ownedEquipment.length,
      machineCount:this.state.machines.length,
      zoneCount:this.state.unlockedZones.length
    });
  }

  updateViewmodel(dt = 0) {
    const vm = this.world.viewmodel;
    const bucket = vm.userData.bucket;
    const water = vm.userData.waterSurface;
    const fraction = this.state.water / Math.max(1,this.capacity());
    water.position.y = -.11 + fraction * .23;
    water.visible = fraction > .02;
    bucket.rotation.x += (this.isPouring ? .72 : -.08 - bucket.rotation.x) * Math.min(1, dt * 5);
    bucket.rotation.z = Math.sin(this.elapsed * 2.2) * .018;
    vm.position.x = .45 + Math.sin(this.elapsed * 2.2) * .009;
    vm.position.y = -.48 + Math.sin(this.elapsed * 4.4) * .008;
    const tool = this.equippedTool();
    const color = tool.id === 'bucket' ? '#91a19a' : tool.id === 'large-bucket' ? '#a2aa9c' : tool.id === 'watering-can' ? '#c08c52' : tool.id === 'sprayer' ? '#6d9d8b' : tool.id === 'hose' ? '#668f63' : tool.id === 'tank' ? '#7b96a4' : '#a4a979';
    bucket.children[1].material.color.set(color);
    const spout = this.world.viewmodel.userData.spout;
    const nozzle = this.world.viewmodel.userData.nozzle;
    const tank = this.world.viewmodel.userData.tank;
    spout.visible = tool.id === 'watering-can' || tool.id === 'hose';
    nozzle.visible = tool.id === 'sprayer' || tool.id === 'mist-cannon' || tool.id === 'restoration-rig';
    tank.visible = tool.id === 'tank' || tool.id === 'restoration-rig';
    bucket.scale.setScalar(tool.id === 'large-bucket' || tool.id === 'tank' ? 1.18 : tool.id === 'restoration-rig' ? 1.3 : 1);

  }

  rebuildTerrainVisuals() {
    for (const cell of this.world.cells) cell.stage = this.getCellStage(cell);
    refreshTerrainVisuals(this.world.terrainVisuals);
  }

  rebuildMachineModels() {
    this.world.machineLayer.clear();
    this.machineGroups = [];
    this.state.machines.forEach(machine => {
      const group = makeMachineModel(machine.type, machine.x, machine.z, this.world.machineLayer);
      group.userData.machineId = machine.id;
      this.machineGroups.push(group);
    });
  }

  save() {
    try {
      const tiles = this.world.cells.filter(c => c.reserve > .05 || c.moisture > 0 || c.fertility > 0 || c.growth > 0 || c.rewarded).map(c => [c.id, Math.round(c.moisture*10)/10, Math.round(c.fertility*10)/10, Math.round(c.growth*1000)/1000, Math.round(c.reserve*10)/10, c.rewarded]);
      const payload = {
        version:1,
        coins:this.state.coins, restorationPoints:this.state.restorationPoints, materials:this.state.materials,
        restoredCount:this.state.restoredCount, water:this.state.water, firstWatered:this.state.firstWatered,
        firstGrass:this.state.firstGrass, questStage:this.state.questStage, ownedEquipment:this.state.ownedEquipment,
        equipped:this.state.equipped, upgrades:this.state.upgrades, machines:this.state.machines,
        unlockedZones:this.state.unlockedZones, totalWatered:this.state.totalWatered, totalPlayTime:this.state.totalPlayTime,
        totalCoinsEarned:this.state.totalCoinsEarned, settings:this.state.settings, tiles, savedAt:Date.now()
      };
      localStorage.setItem('oasis-restoration-save-v1', JSON.stringify(payload));
      this.state.lastSaved = Date.now();
      this.callbacks.onSaved?.(true);
      return true;
    } catch (error) {
      console.warn('Could not save Oasis progress:', error);
      this.callbacks.onSaved?.(false);
      return false;
    }
  }

  load() {
    try {
      const raw = localStorage.getItem('oasis-restoration-save-v1');
      if (!raw) return;
      const data = JSON.parse(raw);
      if (data.version !== 1) return;
      for (const key of ['coins','restorationPoints','materials','restoredCount','water','totalWatered','totalPlayTime','totalCoinsEarned','questStage']) {
        if (data[key] !== undefined) this.state[key] = num(data[key], this.state[key]);
      }
      for (const key of ['firstWatered','firstGrass']) if (data[key] !== undefined) this.state[key] = Boolean(data[key]);
      if (Array.isArray(data.ownedEquipment)) this.state.ownedEquipment = [...new Set(['bucket',...data.ownedEquipment.filter(id => EQUIPMENT.some(e => e.id === id))])];
      if (EQUIPMENT.some(e => e.id === data.equipped) && this.state.ownedEquipment.includes(data.equipped)) this.state.equipped = data.equipped;
      if (data.upgrades) this.state.upgrades = Object.fromEntries(Object.keys(DEFAULT_UPGRADES).map(k => [k, clamp(num(data.upgrades[k]),0,5)]));
      if (Array.isArray(data.machines)) this.state.machines = data.machines.filter(m => MACHINES.some(d => d.id === m.type) && Number.isFinite(m.x) && Number.isFinite(m.z));
      if (Array.isArray(data.unlockedZones)) this.state.unlockedZones = [...new Set(['starting',...data.unlockedZones.filter(id => ZONES.some(z => z.id === id))])];
      if (data.settings) this.state.settings = {...this.state.settings,...data.settings};
      if (Array.isArray(data.tiles)) {
        for (const item of data.tiles) {
          const c = this.cellLookup.get(item[0]);
          if (!c) continue;
          c.moisture = clamp(num(item[1]),0,100);
          c.fertility = clamp(num(item[2]),0,100);
          c.growth = clamp(num(item[3]),0,1);
          c.reserve = clamp(num(item[4]),0,24);
          c.rewarded = Boolean(item[5]);
        }
      }
      this.state.water = clamp(this.state.water,0,this.capacity());
      this.rebuildTerrainVisuals();
    } catch (error) {
      console.warn('Save file could not be loaded:', error);
    }
  }

  resetProgress() {
    localStorage.removeItem('oasis-restoration-save-v1');
    const settings = {...this.state.settings};
    this.state = defaultState();
    this.state.settings = settings;
    this.world.cells.forEach(c => Object.assign(c,{stage:0,moisture:0,fertility:0,growth:0,reserve:0,rewarded:false}));
    this.rebuildTerrainVisuals();
    this.rebuildMachineModels();
    this.updateCallbacks();
    this.save();
  }

  setupAudio() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    try {
      const context = new AudioCtx();
      const master = context.createGain();
      master.gain.value = this.state.settings.sfx ?? .7;
      master.connect(context.destination);
      const music = context.createGain();
      music.gain.value = this.state.settings.music ?? .18;
      music.connect(context.destination);
      const low = context.createBiquadFilter();
      low.type = 'lowpass'; low.frequency.value = 250;
      const osc = context.createOscillator();
      osc.type = 'triangle'; osc.frequency.value = 48;
      const ambientGain = context.createGain(); ambientGain.gain.value = .018;
      osc.connect(low); low.connect(ambientGain); ambientGain.connect(music); osc.start();
      const lfo = context.createOscillator(); lfo.frequency.value = .12;
      const lfoGain = context.createGain(); lfoGain.gain.value = 10;
      lfo.connect(lfoGain); lfoGain.connect(osc.frequency); lfo.start();
      this.audio = { context, master, music, ambientGain, osc, lfo };
    } catch (error) { console.warn('Audio disabled:', error); }
  }

  sfx(name) {
    const a = this.audio;
    if (!a || a.context.state !== 'running') return;
    const ctx = a.context;
    const now = ctx.currentTime;
    const gain = ctx.createGain();
    const osc = ctx.createOscillator();
    const volume = (this.state.settings.sfx ?? .7) * .16;
    const presets = {
      collect:[560,820,.12,'sine'], pour:[340,210,.18,'triangle'], purchase:[480,760,.2,'sine'], unlock:[360,660,.32,'triangle'], grow:[540,880,.28,'sine'], equip:[300,370,.07,'square'], jump:[180,250,.09,'sine'], empty:[145,90,.17,'triangle']
    };
    const p = presets[name] || presets.equip;
    osc.type = p[3]; osc.frequency.setValueAtTime(p[0],now); osc.frequency.exponentialRampToValueAtTime(Math.max(40,p[1]),now+p[2]);
    gain.gain.setValueAtTime(Math.max(.001,volume),now); gain.gain.exponentialRampToValueAtTime(.001,now+p[2]);
    osc.connect(gain); gain.connect(a.master); osc.start(now); osc.stop(now+p[2]+.02);
  }

  setGraphicsQuality(level) {
    if (!this.state.settings) this.state.settings = {...defaultState().settings};
    this.state.settings.quality = level;
    const low = level === 'low';
    const medium = level === 'medium';
    this.renderer.shadowMap.enabled = !low;
    this.sun.castShadow = !low;
    this.sun.shadow.mapSize.set(low ? 512 : medium ? 768 : 1024, low ? 512 : medium ? 768 : 1024);
    this.hemi.intensity = low ? 1.5 : 2;
    this.resize();
  }

  updateToast(dt) {
    if (!this.toastTimer) return;
    this.toastTimer -= dt;
    if (this.toastTimer <= 0) this.callbacks.onToastEnd?.();
  }

  toast(message) {
    this.lastToast = message;
    this.toastTimer = 2.2;
    this.callbacks.onToast?.(message);
  }

  getSnapshot() { return this.state; }

  dispose() {
    this.save();
    this.isRunning = false;
    this.resizeObserver?.disconnect();
    window.removeEventListener('keydown',this.onKeyDown);
    window.removeEventListener('keyup',this.onKeyUp);
    document.removeEventListener('mousemove',this.onMouseMove);
    document.removeEventListener('pointerlockchange',this.onPointerLock);
    this.renderer.domElement.removeEventListener('mousedown',this.onMouseDown);
    window.removeEventListener('mouseup',this.onMouseUp);
    this.renderer.dispose();
    this.audio?.context?.close?.();
  }
}
